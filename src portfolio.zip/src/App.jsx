import React from 'react';
import Navbar1 from "./components/Navbar1";
import Home from "./components/Home";
import Contact from "./components/Contact";
import About from "./components/About";

//import Footer from "./components/Footer";

function App() {
  return (
       
       <>
       
       <Home/>
       <br/>
       <Navbar1/>
       <br/>
       <Contact/>
       <br/>
       <About/>
      

      
       
       </>
  );
}

export default App;